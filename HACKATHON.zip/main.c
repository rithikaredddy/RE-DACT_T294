#include <stdio.h>
#include <string.h>
#include <regex.h>

void redact_pattern(const char *input, const char *pattern, const char *label, char *output){
    regex_t regex;
    regmatch_t match;
    char buffer[10000];
    strcpy(buffer, input);
    char temp[10000] = "";
    if(regcomp(&regex, pattern, REG_EXTENDED)){
        fprintf(stderr, "Could not compile regex\n");
        return;
    }
    char *cursor = buffer;
    while(!regexec(&regex, cursor, 1, &match, 0)){
        strncat(temp, cursor, match.rm_so);
        strcat(temp, label);
        cursor += match.rm_eo;
    }
    strcat(temp, cursor);
    strcpy(output, temp);
    regfree(&regex);
}

int main(){
    char input[1000] = "Hello, my name is Rithika.You can reach me at rithika@gmail.com or call me at 1234567890.Rithika will respond shortly.";
    char temp1[1000], temp2[1000], temp3[1000];
    // Redact email
    redact_pattern(input, "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}", "[EMAIL REDACTED]", temp1);
    
    //Redact phone
    redact_pattern(temp1, "[0-9]{3}[-.][0-9]{3}[-.][0-9]{4}", "[PHONE REDACTED]", temp2);
    
    //Redacted names
    redact_pattern(temp2, "\\b[A-Z][a-z]+\\b","[NAME REDACTED]", temp3);
    
    printf("Redacted Output:\n%s\n", temp3);
    return 0;
}